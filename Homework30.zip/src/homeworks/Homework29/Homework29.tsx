import { useState } from "react"

import Counter from "../../components/Counter/Counter"

import { Homework29Wrapper } from "./styles"

function Homework29() {
  return (
    <Homework29Wrapper>
      <Counter/>
    </Homework29Wrapper>
  );
}

export default Homework29;