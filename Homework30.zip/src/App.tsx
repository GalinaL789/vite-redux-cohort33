import Homework29 from "./homeworks/Homework29/Homework29"

function App() {
  return (
    <>
       <Homework29/>
    </>
  )
}

export default App
