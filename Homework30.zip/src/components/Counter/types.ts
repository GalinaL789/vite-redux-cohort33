export interface CounterProps {
    count: number;
    onMinus: () => void;
    onPlus: () => void;
    onMultiply:() =>void;
    onDivide:() =>void;
    
  }
  