export interface CounterSliceState {
  count: number
}