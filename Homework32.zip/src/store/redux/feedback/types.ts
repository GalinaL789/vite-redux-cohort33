export interface FeedbackSliceState {
    likeCount: number
    dislikeCount: number
  }