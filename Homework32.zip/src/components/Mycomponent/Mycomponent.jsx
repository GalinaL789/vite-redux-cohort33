function Mycomponent()
{

    return <div>Mycomponent</div>
}
export default Mycomponent;