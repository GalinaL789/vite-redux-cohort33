import Counter from "components/Counter/Counter";
import Feedback from "components/Feedback/Feedback";

//import Feedback from 'components/Feedback/Feedback';
function Homework31()
{
    return  <Feedback/> 
}
export default Homework31;