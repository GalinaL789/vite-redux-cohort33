import Feedback from "components/Feedback/Feedback"

import { Homework31Wrapper } from "./styles"

function Homework32() {
  return (
    <Homework31Wrapper>
      {/* <Feedback /> */}
    </Homework31Wrapper>
  )
}

export default Homework32